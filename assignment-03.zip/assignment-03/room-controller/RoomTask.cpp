#include "RoomTask.h"

void RoomTask::setValue(int value) {
  this->value = value;
};
int RoomTask::getValue() {
  return this->value;
};
