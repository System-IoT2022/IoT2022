package com.example.room_app;

import java.util.UUID;

public class C {
    public static final String TAG = "RemoteLedApp";
    //app random geerated uuid
    public static final UUID DEFAULT_DEVICE_UUID = UUID.fromString("feefdc3e-b5f1-11ed-afa1-0242ac120002");
    public class emulator {
        public static final String HOST_IP = "10.0.2.2";
        public static final int HOST_PORT = 8080;
    }
}
